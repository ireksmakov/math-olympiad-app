export type AnswerType='integer'|'decimal'|'fraction'|'multiple_choice'|'text';
export type Problem={id:number;title:string;grade:number;topic:string;subtopic:string;difficulty:1|2|3|4|5;statement:string;answerType:AnswerType;correctAnswer:string;options?:string[];solution:string;shortSolution:string;hints:[string,string,string];commonMistakes:string[];skills:string[];estimatedTime:number;sourceType:'original'|'classic_idea'|'teacher_created';author:string};
export type Attempt={problemId:number;answer:string;isCorrect:boolean;hintsUsed:number;timeSeconds:number;createdAt:string};
export type Profile={name:string;grade:number;role:'student'|'teacher'};
export type TeacherGroup={id:string;name:string;students:string[]};
export type Assignment={id:string;groupId:string;problemIds:number[];dueDate:string;title:string};
