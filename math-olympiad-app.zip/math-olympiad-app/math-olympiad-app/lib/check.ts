import {Problem} from './types';
function gcd(a:number,b:number){a=Math.abs(a);b=Math.abs(b);while(b){[a,b]=[b,a%b]}return a||1}
function normalizeFraction(v:string){const m=v.trim().match(/^(-?\d+)\s*\/\s*(-?\d+)$/);if(!m)return null;let a=Number(m[1]),b=Number(m[2]);if(!b)return null;if(b<0){a=-a;b=-b}const g=gcd(a,b);return `${a/g}/${b/g}`}
export function checkAnswer(problem:Problem,input:string){const a=input.trim();const c=problem.correctAnswer.trim();if(problem.answerType==='fraction'){const af=normalizeFraction(a),cf=normalizeFraction(c);if(af&&cf)return af===cf;const n=Number(a);const [x,y]=c.split('/').map(Number);return Number.isFinite(n)&&Math.abs(n-x/y)<1e-9}
if(problem.answerType==='integer'||problem.answerType==='decimal'){const an=Number(a.replace(',','.')),cn=Number(c.replace(',','.'));return Number.isFinite(an)&&Math.abs(an-cn)<1e-9}
return a.toLocaleLowerCase('ru-RU')===c.toLocaleLowerCase('ru-RU')}
