'use client';
import {Attempt,Assignment,Profile,TeacherGroup} from './types';
const key=(x:string)=>`matholymp:${x}`;
export function load<T>(name:string,fallback:T):T{if(typeof window==='undefined')return fallback;try{const v=localStorage.getItem(key(name));return v?JSON.parse(v):fallback}catch{return fallback}}
export function save<T>(name:string,value:T){if(typeof window!=='undefined')localStorage.setItem(key(name),JSON.stringify(value))}
export function getProfile(){return load<Profile>('profile',{name:'Ученик',grade:6,role:'student'})}
export function getAttempts(){return load<Attempt[]>('attempts',[])}
export function addAttempt(a:Attempt){const all=getAttempts();all.push(a);save('attempts',all)}
export function getFavorites(){return load<number[]>('favorites',[])}
export function toggleFavorite(id:number){const fav=getFavorites();const next=fav.includes(id)?fav.filter(x=>x!==id):[...fav,id];save('favorites',next);return next}
export function getGroups(){return load<TeacherGroup[]>('groups',[])}
export function getAssignments(){return load<Assignment[]>('assignments',[])}
