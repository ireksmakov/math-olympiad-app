import './globals.css';
import type { Metadata } from 'next';
import Nav from '@/components/Nav';
export const metadata: Metadata = { title:'Математическая олимпиада 1–11 класс', description:'Тренажёр олимпиадной математики' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ru"><body><Nav/><main><div className="container">{children}</div></main><footer className="footer"><div className="container">Учебный MVP · Авторские задачи · Данные прогресса сохраняются локально в браузере</div></footer></body></html>}
