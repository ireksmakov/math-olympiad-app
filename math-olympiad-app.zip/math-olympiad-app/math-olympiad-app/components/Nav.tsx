'use client';
import Link from 'next/link';
export default function Nav(){return <header className="nav"><div className="container navInner"><Link className="brand" href="/">МАТЕМАТИЧЕСКАЯ ОЛИМПИАДА</Link><nav className="navlinks"><Link href="/tasks">Задачи</Link><Link href="/training">Тренировка</Link><Link href="/random">Случайная</Link><Link href="/olympiad">Олимпиада</Link><Link href="/results">Результаты</Link><Link href="/favorites">Избранное</Link><Link href="/teacher">Для учителя</Link></nav><Link className="btn secondary" href="/profile">Профиль</Link></div></header>}
